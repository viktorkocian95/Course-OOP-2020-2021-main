#include "AbstractStringOutput.h"

AbstractStringOutput::AbstractStringOutput()
{
}

string AbstractStringOutput::ToString()
{
    return string();
}
