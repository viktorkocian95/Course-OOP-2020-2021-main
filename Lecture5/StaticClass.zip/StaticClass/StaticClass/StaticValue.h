#pragma once
class StaticValue
{
private:
	static int value;
	int defaultInterest;

public:
	static int getValue();
	static void setValue(int v);
};

